<?php 

header("Location: ../Pages/");
exit;